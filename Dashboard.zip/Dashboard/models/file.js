const mongoose = require('mongoose')

const fileSchema = new mongoose.Schema({
    filename: String, 
    employeeName : String 
}) ; 

const File = mongoose.model('File', fileSchema) ;

module.exports = File ; 