const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const hbs = require('hbs')
const path = require('path')


const fileRoutes = require('./routes/fileRoutes')

const dotenv = require('dotenv').config()

const app = express()

const PORT = process.env.PORT || 3000


mongoose.connect('mongodb://localhost:27017/DashboardDB')
.then(()=>{
    console.log('Connected to the database') ; 
}).catch(err => {
    console.error('Error connecting to the database ');
})

// setting up dotengine as the view engine

app.engine('hbs', hbs.__express)
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'hbs')


app.use(express.urlencoded({extended: true}))

app.use('/', fileRoutes)

app.listen(PORT, ()=>{
    console.log(`Server running on http://localhost:${PORT}`);
})