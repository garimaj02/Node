const express = require('express')
const router = express.Router()

const File = require('../models/file')

// display form to add a  new file record 

router.get('/add', (req, res)=>{
    res.render('addFile') ;
}) ; 

// save the file record 

router.post('/add', async(req, res)=>{
    const {fileName, employeeName} = req.body ; 
    try {
        const file = new File({fileName , employeeName}) ; 
        await file.save() ; 
        res.redirect(`/employee/${employeeName}`) ; 
    } catch (err) {
        console.error('Error saving the file', err);
        res.status(500).send('Error saving file') ; 
    }
}) ; 

// display files by employee name 

router.get('/employee/:name', async (req, res)=>{
    const {name} = req.params ; 
    try{
        const files = await File.find({employeeName: name}) ; 
        res.render('filesByEmployee', {files}) ; 
    } catch(err){
        console.error('Error fetching files by employee name: ', err)
        res.status(500).send('Error fetching files') ; 
    }
}) ; 

module.exports = router