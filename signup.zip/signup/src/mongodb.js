module.exports = function (nosql) {

// schema

 nosql.model('RegisterUser', new nosql.Schema({
        name: {
            type: String,
        },
        email: {
            type: String,
        },
        password: {
            type: String,
        },
        contact: {
            type: Number,
        },
        gender: {
            type: String, 
        },
        is_deleted: { type: Boolean, default: false }, 
        createdAt: { type: Date, default: Date.now }
    }));



};
