const express = require("express");
const path = require("path");
const hbs = require("hbs");
const dotenv = require("dotenv").config();
const mongoose = require("mongoose")
const  pageRouter = require("./routers/pageRoute")
const bodyParser = require("body-parser") ; 

mongoose.connect(process.env.DB_URL);
require('./src/mongodb')(mongoose);

const app = express();


const PORT = process.env.PORT || 5000;

app.use(express.json()) ; // incoming http request parse json format

app.use(express.urlencoded({extended : true}))

app.use(function (req, res, next) {
    req.nosql = mongoose;
    global.nosql = req.nosql;
    next();
  });

// my routes 

app.use('/', pageRouter) ; 

app.set('view engine', 'hbs');

const templatesPath = path.join(__dirname + "/templates") ;
app.set("views", templatesPath) ; 


app.listen(PORT, () => {
    console.log(`port connected on http://localhost:${PORT}`);
})