const express = require('express') ; 
const router = express.Router()
const pageController = require("../controllers/pageController")

router.get('/login', pageController.loginPage) ; 
router.post('/login', pageController.loginData) ; 

router.get('/signup', pageController.signupPage) ; 
router.post('/signup', pageController.signupData) ; 

router.get('/', pageController.homePage) ; 

module.exports = router ; 