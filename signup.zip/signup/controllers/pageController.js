var pageController = {}

const loginPage = function (req, res) {
    res.render("login")
}

const signupPage = function (req, res) {
    res.render("signup")
}

const homePage = function (req, res) {
    res.render("home")
}

const signupData = async (req, res) => {
    const data = {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        contact: req.body.contact,
        gender: req.body.gender
    };

    try {
        const registeruser = await nosql.model("RegisterUser");
        const results = await registeruser.insertMany([data]);
        res.render("home", { results: results }); // Render after successful database operation
    } catch (error) {
        console.error("Error occurred while inserting data:", error);
        res.status(500).send("An error occurred while processing your request.");
    }
};

const loginData = async (req, res,email) => {
    try {
      var registeruser = nosql.model("RegisterUser")
      const check = await registeruser.findOne({ name: req.body.name })
  
      if (check) { // Check if user exists
        if (check.password === req.body.password) { // Compare passwords
          res.render("home");
        } else {
          res.send("wrong password");
        }
      } else {
        res.send("User not found"); // Handle case where user doesn't exist
      }
    } catch (error) {
      console.error("Error occurred while logging in:", error);
      res.status(500).send("An error occurred while processing your request.");
    }
  };



pageController.loginData = loginData
pageController.homePage = homePage
pageController.signupData = signupData
pageController.loginPage = loginPage
pageController.signupPage = signupPage

module.exports = pageController