const express = require("express");
const router = express.Router();
const pageControllers = require("../controllers/pageControllers")

router.get('/login',pageControllers.loginPage)
router.post('/login', pageControllers.loginData)

router.get('/signup', pageControllers.signupPage)
router.post('/signup', pageControllers.signupData) ; 

router.get('/home', pageControllers.homePage) ; 

// router.get('/',pageControllers.home)

module.exports = router;