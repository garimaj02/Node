const express = require("express");
const router = express.Router();
const bugController = require("../controllers/bugController");

router.route("/").get(bugController.FetchAll);

router.route("/create").post(bugController.Create);

router.post("/edit", bugController.Edit);

router.post("/delete", bugController.Delete);

module.exports = router;