require('dotenv').config()
process.env.TZ = "Asia/Kolkata";
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var engine = require('express-dot-engine');
const http = require("http");

// requiring mongodb schema and model

const collection = require("./bootstrap/models") ; 

const indexRouter = require("./routes/dev");
const devBugs = require("./routes/bugs");



///my routes

var pageRouter = require("./routes/page") 

const mongoose = require("mongoose");
var app = express();

mongoose.connect(process.env.DB_URL);

require('./bootstrap/models')(mongoose);

app.engine('dot', engine.__express);
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'dot');

app.use(function (req, res, next) {
  req.nosql = mongoose;
  global.nosql = req.nosql;
  next();
});

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// get and post login data


// get and post signup data



// app.use('/', indexRouter);
app.use("/dev_bug", devBugs);
app.use("/",pageRouter)

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});


module.exports = app;
