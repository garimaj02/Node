const mongoose =  require("mongoose");

const stateSchema = mongoose.Schema({

    name:{
        type:String
    },
    country_short_name:{
        type:String
    }
});

module.exports  = mongoose.model('State',stateSchema);