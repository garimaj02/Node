const mongoose = require("mongoose")

mongoose.connect("mongodb://localhost:27017/its")

const express = require("express");
const app = express();

app.listen(8000, function(){
    console.log("server is running..");
});