const City = require('../models/cityModel')
const Country = require('../models/countryModel')
const State = require('../models/stateModel')

var indexController = { }

const getCountries = async(req,res) => {
       try{
        const countries =  await Country.find({ });
        res.status(200).send({success:true,msg:'Countries details',data:countries})
       }catch(error){
        res.status(400).send({success:false,msg:error.message})
       }
}

indexController.getCountries = getCountries ; 

module.exports = indexController ;

 