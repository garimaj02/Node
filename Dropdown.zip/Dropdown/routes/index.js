var express = require('express');
var router = express.Router();
const bodyParser =  require('body-parser');
const indexController = require('../controllers/indexController')


router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended:true}));


/* GET home page. */

// router.get('/get-countries',  );

router.get('/getcountries', indexController.getCountries)

module.exports = router;
