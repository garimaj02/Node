const express = require('express')
const router = express.Router()

const File = require('../models/file')

const routeController = require('../controllers/routeController')


// display form to add a  new file record 

router.get('/add', routeController.addFile) ; 

// save the file record 

router.post('/add', routeController.saveRecord) ; 

// display files by employee name 

router.get('/employee/:name', routeController.displayByEmployee) ; 

// display details of file distribution among employees

router.get('/displayInfo', routeController.displayAllData)

router.put('/displayInfo/:id' , routeController.updateData)

module.exports = router