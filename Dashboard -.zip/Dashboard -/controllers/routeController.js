const File = require('../models/file')

var routeController = {}

const addFile = (req, res) => {
    res.render('addFile');
}

// save the records (employeeName, fileName) into the database

const saveRecord = async (req, res) => {
    const { fileName, employeeName } = req.body;
    console.log('Received data: ', {fileName, employeeName})
    try {
        const files = new File({ fileName, employeeName });
        await files.save();
        console.log('Record saved successfully')
        // res.render('display', {files});
        res.redirect('/displayInfo')
    } catch (err) {
        console.error('Saving the file', err);
        res.status(500).send('Error saving file');
    }
}

// display the files distributed to employee(id)

const displayByEmployee = async (req, res) => {
    const { name } = req.params;
    try {
        const files = await File.find({ employeeName: name });
        res.render('filesByEmployee', { files });
    } catch (err) {
        console.error('Error fetching files by employee name: ', err)
        res.status(500).send('Error fetching files');
    }
}


// display the details of file and corresponding employee

const displayAllData = async (req, res)=> {
    try{
        const files = await File.find() ; 
        res.render('display', {files}) ; 
    } catch (error) {
        console.error('Error retrieving files: ', error) ; 
        res.status(500).send('Internal Server Error') ; 
    }
} ; 

// update the records 

const updateData = async (req, res)=> {
    try{
        const file = await File.findByIdAndUpdate(req.params.id , req.body , {new : true}) ; 
        res.send(file) ; 
    } catch(error) {
        res.status(404).send({message: 'Book not found'}) ; 
    }
}

routeController.updateData = updateData
routeController.displayAllData = displayAllData
routeController.displayByEmployee = displayByEmployee
routeController.saveRecord = saveRecord
routeController.addFile = addFile

module.exports = routeController